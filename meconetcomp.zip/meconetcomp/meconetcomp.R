
# # This script was fine-tuned based on the code provided in Liu's paper (https://doi.org/10.1002/imt2.71).

ls()
rm(list=ls())
setwd("C:/data")
library(microeco)
otu_table_16S = read.table("otu_table_16S.txt", head=T, row.names=1)
taxonomy_table_16S = read.table("taxonomy_table_16S.txt", head=T, row.names=1)
sample_info_16S = read.table("sample_info_16S.txt", head=T, row.names=1)

# use pipe operator in magrittr package
library(magrittr)
# fix the random number generation to make the results repeatable
set.seed(123)
# make the plotting background same with the tutorial
library(ggplot2)
theme_set(theme_bw())
class(otu_table_16S)
otu_table_16S[1:5, 1:5]
class(taxonomy_table_16S)
taxonomy_table_16S[1:5, 1:3]
# make the taxonomic information unified, very important
taxonomy_table_16S %<>% tidy_taxonomy
class(sample_info_16S)
sample_info_16S[1:5, ]
sediment_amp <- microtable$new(sample_table = sample_info_16S, otu_table = otu_table_16S, tax_table = taxonomy_table_16S)
sediment_amp
library(microeco)
library(meconetcomp)
library(magrittr)
library(ggplot2)
sediment_amp_network <- list()
tmp <- clone(sediment_amp)
tmp$sample_table%<>%subset(Group == "MCS-RH")
# trim all files in the object
tmp$tidy_dataset()
# Due to the previous analysis of filtering low abundance features, this script does not filter the features.
tmp <- trans_network$new(dataset = tmp, cor_method = "pearson", filter_thres = 0.0000)
#COR_ p_ _thres represents the p value threshold
# COR_ cut denotes the correlation coefficient threshold
tmp$cal_network(COR_p_thres = 0.05, COR_cut=0.9)
# put the network into the list .
sediment_amp_network$MCSRH <- tmp
# Repeat operation.
tmp <-clone(sediment_amp)
tmp$sample_table %<>%subset(Group == "MCS-HT")
tmp$tidy_dataset()
tmp <- trans_network$new(dataset = tmp, cor_method ="pearson", filter_thres =0.0000)
tmp$cal_network(COR_p_thres =0.05, COR_cut =0.9)
sediment_amp_network$MCSHT <- tmp
# Repeat operation.
tmp <- clone(sediment_amp)
tmp$sample_table %<>%subset(Group == "MFS-LH")
tmp$tidy_dataset()
tmp <- trans_network$new(dataset = tmp, cor_method ="pearson", filter_thres = 0.0000)
tmp$cal_network(COR_p_thres =0.05, COR_cut = 0.9)
sediment_amp_network$MFSLH <- tmp
sediment_amp_network %<>% cal_module(undirected_method ="cluster_fast_greedy")
# Topological Properties of Networks.
tmp <- cal_network_attr(sediment_amp_network)
write.csv(tmp, "sediment_amp_network_attrubutes.csv")
# Obtain node and edge attributes.
sediment_amp_network %<>% get_node_table(node_roles = TRUE) %>% get_edge_table

# Search and merge res_Node_Table in network objects.
tmp <- node_comp(sediment_amp_network, property = "name")
tmp1 <- trans_venn$new(tmp, ratio = "numratio")
g1 <- tmp1$plot_venn(fill_color = FALSE, color_circle = c("#D03918","#E5A84B","#5DA39D"))
ggsave("sediment_amp_node_overlap.pdf", g1, width = 7, height = 6)
tmp$cal_betadiv(method = "jaccard")
tmp$beta_diversity$jaccard
tmp <- node_comp(sediment_amp_network)
tmp1 <- trans_venn$new(tmp)
# Remove the parts that do not intersect here for visualization.
tmp1$data_summary %<>% .[.[, 1] != 0, ]
g1 <- tmp1$plot_bar()
ggsave("sediment_amp_node_overlap2.pdf", g1, width = 10, height = 6)

# Search and merge res_edge_Table in network objects.
tmp <- edge_comp(sediment_amp_network)
tmp1 <- trans_venn$new(tmp, ratio = "numratio")
g1 <- tmp1$plot_venn(fill_color = FALSE)
ggsave("sediment_amp_edge_overlap.pdf", g1, width = 7, height = 6)
tmp$cal_betadiv(method = "jaccard")
tmp$beta_diversity$jaccard
tmp <- edge_comp(sediment_amp_network)
tmp1 <- trans_venn$new(tmp)
tmp1$data_summary %<>% .[.[, 1] != 0, ]
# Show only shared
tmp1$data_summary %<>% .[grepl("&", rownames(.)), ]
g1 <- tmp1$plot_bar()
ggsave("sediment_amp_edge_overlap2.pdf", g1, width = 10, height = 6)

# Extracting overlapping edges of different networks
# Search and merge res_edge_Table in network objects.
tmp <- edge_comp(sediment_amp_network)
tmp1 <- trans_venn$new(tmp)
# Convert set information to a new microtable object
tmp2 <- tmp1$trans_comm()
# Using subset_ Network extraction results, where the intersection of three networks is extracted
# Use colnames (tmp2 $otu_table) to find names
Intersec_all <-subset_network(sediment_amp_network, venn = tmp2, name ="MCSRH&MCSHT&MFSLH")
Intersec_all$save_network("Intersec_all.gexf")





