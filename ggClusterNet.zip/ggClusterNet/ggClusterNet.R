ls()
rm(list=ls())
setwd("C:/data")
getwd()
library(rlang)
library(scales)
library(igraph)
library(psych)
library(Hmisc)
library(BiocManager)
#BiocManager::install("phyloseq", version = "3.14")
library(phyloseq)
library(network)
library(sna)
library(tidyverse)
library(psych)
library(ggnewscale)
library(remotes)
library(usethis)
library(devtools)
library(ggalluvial)
#remotes::install_github("taowenmicro/ggClusterNet")
library(ggClusterNet)
otu = read.table("OTU3.txt", head=T, row.names=1)

otu <- otu[,which(colSums(otu)>=0.005)]# Filter low abundance OTUs.

# Calculate correlation
occor<-rcorr(as.matrix(otu),type = "pearson")
occor.r = occor$r 
occor.p = occor$P 
# Multiple testing correction using Benjamini-Hochberg standard false discovery rate correction ("FDR-BH")
occor.p<-p.adjust(occor.p, method="BH")

# Filter correlations that do not meet the criteria.
occor.r[occor.p>0.05|abs(occor.r)<0.9] = 0
occor$r=occor.r
occor$p=occor.p
write.csv(occor.r," OTU3_r.occor.0.05.0.9.csv")
write.csv(occor.p," OTU3_p.occor.0.05.0.9.csv")

# Calculate Zi and pi value
cor=occor[[1]]
head(cor)
result4 = nodeEdge(cor = cor)
edge = result4[[1]]
node = result4[[2]]
igraph  = igraph::graph_from_data_frame(edge, directed = FALSE, vertices = node)
res = ZiPiPlot(igraph = igraph,method = "cluster_fast_greedy")
p <- res[[1]]
p <- p + labs(x="Among-module connectivity Pi",y="Within-module connectivity Zi")
p <- p + theme(axis.title.x=element_text(vjust=1,  
                                         size=15),  # X axis title
               axis.title.y=element_text(size=15,
               ),  # Y axis title
               axis.text.x=element_text(size=12,
                                        face = "bold",
                                        
                                        vjust=.5),  # X axis text
               axis.text.y=element_text(size=12,
                                        face = "bold",
                                        
               ))  # Y axis text
p <- p + theme(legend.title = element_text(size=20, 
), 
legend.text = element_text(size=18),
)
p
ggsave("p.jpg")
p
dev.off()
q <- res[[2]]
q
write.csv(q," OTU3_zipi.csv")

# Calculate network topology attributes
edge_density(igraph)
transitivity(igraph, type="global")
transitivity(igraph, type="local")
transitivity(igraph, type="average")
dat = net_properties(igraph)
write.csv(dat," OTU3_Network_properties.csv")
nodepro = node_properties(igraph)
head(nodepro)
write.csv(nodepro," OTU3_node_properties.csv")
write_graph(igraph, " FH200.graphml","graphml")

